<?php

$uid 	='30461482';
$n 	='ffffffff97796cec000000004a7dbcb2';
# copy paste data u dan n dari packet captur caping